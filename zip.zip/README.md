# MG CoDe Website

موقع تعريفي متجاوب لمجتمع MG CoDe، مبني باستخدام HTML وCSS وJavaScript فقط.

## الصفحات
- `index.html` — الرئيسية.
- `accounts.html` — حسابات وروابط السيرفر.
- `about.html` — شرح المجتمع والخدمات.
- `contact.html` — معلومات التواصل.
- `bots.html` — بوتات MG وروابط الدعوة.

## الصور المطلوبة
أنشئ مجلد `assets` وضع الصور التالية داخله بالأسماء الدقيقة:
- `15.png` — شعار الموقع.
- `11.png` — شعار MG Security.
- `9.png` — شعار MG System.
- `10.png` — شعار MG Ticket.

الصور غير مرفقة في الملفات الأصلية التي وصلتني؛ لذلك أضف صورك قبل النشر حتى تظهر الشعارات.

## تشغيل الموقع محلياً
افتح `index.html` في المتصفح. لا يحتاج المشروع إلى تثبيت حزم أو تشغيل Node.js.

## رفع المشروع إلى GitHub
افتح PowerShell داخل مجلد المشروع ونفّذ:

```powershell
git init
git add .
git commit -m "Create MG CoDe website"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

استبدل `USERNAME/REPOSITORY` باسم حسابك ومستودعك على GitHub.

## النشر عبر GitHub Pages
من المستودع في GitHub:
1. افتح Settings.
2. اختر Pages.
3. من Build and deployment اختر Deploy from a branch.
4. اختر `main` والمجلد `/ (root)` ثم Save.

بعدها سيظهر رابط الموقع في صفحة Pages.
